;TITLE BMP Image Processor - MASM 32-bit / Irvine32
; ------------------------------------------------------------
; Supported input: Windows BMP, BITMAPINFOHEADER-or-larger DIB,
; 24 bits per pixel, BI_RGB (uncompressed), max 10 MiB.
; Filters: inversion, grayscale, threshold, brightness, mirror.
; Build with 32-bit MASM and the Irvine32 library.
; ------------------------------------------------------------

INCLUDE Irvine32.inc

MAX_FILE_SIZE EQU 10485760        ; 10 MiB
MAX_NAME_LENGTH EQU 259

.data
bmpBuffer       BYTE (MAX_FILE_SIZE + 1) DUP(?) ; +1 detects oversized files
inputName       BYTE (MAX_NAME_LENGTH + 1) DUP(0)
outputName      BYTE (MAX_NAME_LENGTH + 1) DUP(0)

inputHandle     DWORD ?
outputHandle    DWORD ?
bytesRead       DWORD 0
bytesWritten    DWORD 0

imgWidth        DWORD 0
imgHeight       DWORD 0              ; absolute number of rows
pixelOffset     DWORD 0
 dibHeaderSize  DWORD 0
dibHeightRaw    SDWORD 0
rowStride       DWORD 0
rowPadding      DWORD 0
pixelBytes      DWORD 0

bmpValid        DWORD 0
ioStatus        DWORD 0              ; 1 = success, 0 = failure
menuChoice      DWORD 0

menuText BYTE 0Dh,0Ah,"===========================================",0Dh,0Ah,"          BMP IMAGE PROCESSOR",0Dh,0Ah,"===========================================",0Dh,0Ah,"1. Color inversion",0Dh,0Ah,"2. Grayscale conversion",0Dh,0Ah,"3. Black-and-white threshold",0Dh,0Ah,"4. Increase brightness (+30)",0Dh,0Ah,"5. Horizontal mirror",0Dh,0Ah,"6. Exit",0Dh,0Ah,"Enter your choice: ",0
inputPrompt BYTE 0Dh,0Ah,"Enter input BMP filename: ",0
outputPrompt BYTE 0Dh,0Ah,"Enter output BMP filename (use a different name): ",0
loadedMsg BYTE 0Dh,0Ah,"Image loaded and validated. Dimensions: ",0
xMsg BYTE " x ",0
processingMsg BYTE 0Dh,0Ah,"Processing...",0
savedMsg BYTE 0Dh,0Ah,"Success: processed image saved to ",0
invalidMenuMsg BYTE 0Dh,0Ah,"Invalid menu choice. Select 1-6.",0
openErrorMsg BYTE 0Dh,0Ah,"Error: could not open the input file.",0
readErrorMsg BYTE 0Dh,0Ah,"Error: could not read the input file or it exceeds 10 MiB.",0
bmpErrorMsg BYTE 0Dh,0Ah,"Error: unsupported or invalid BMP.",0Dh,0Ah,"Use a 24-bit, uncompressed BMP with a valid Windows DIB header.",0
createErrorMsg BYTE 0Dh,0Ah,"Error: could not create the output file.",0
writeErrorMsg BYTE 0Dh,0Ah,"Error: could not write the complete output file.",0
sameNameMsg BYTE 0Dh,0Ah,"Error: input and output names must be different. Choose another output name.",0
exitMsg BYTE 0Dh,0Ah,"Exiting BMP Image Processor.",0

.code

main PROC
MainMenu:
    mov edx, OFFSET menuText
    call WriteString
    call ReadInt
    mov menuChoice, eax

    cmp eax, 6
    je ExitProgram
    cmp eax, 1
    jb InvalidChoice
    cmp eax, 5
    ja InvalidChoice

    ; Get input filename.
    mov edx, OFFSET inputPrompt
    call WriteString
    mov edx, OFFSET inputName
    mov ecx, MAX_NAME_LENGTH
    call ReadString

    call ReadBMP
cmp ioStatus, 1
jne MainMenu

mov edx, OFFSET inputName
call WriteString
call Crlf

mov eax, bytesRead
call WriteDec
call Crlf

mov eax, DWORD PTR [bmpBuffer + 14]
call WriteDec
call Crlf

mov eax, DWORD PTR [bmpBuffer + 10]
call WriteDec
call Crlf

mov eax, DWORD PTR [bmpBuffer + 18]
call WriteDec
call Crlf

mov eax, DWORD PTR [bmpBuffer + 22]
call WriteDec
call Crlf

movzx eax, WORD PTR [bmpBuffer + 26]
call WriteDec
call Crlf

movzx eax, WORD PTR [bmpBuffer + 28]
call WriteDec
call Crlf

mov eax, DWORD PTR [bmpBuffer + 30]
call WriteDec
call Crlf

call ParseBMPHeader
mov eax, rowStride
call WriteDec
call Crlf

mov eax, rowPadding
call WriteDec
call Crlf

mov eax, pixelBytes
call WriteDec
call Crlf

mov eax, pixelOffset
call WriteDec
call Crlf

mov eax, bmpValid
call WriteDec
call Crlf
    cmp bmpValid, 1
    jne InvalidBMP

    mov edx, OFFSET loadedMsg
    call WriteString
    mov eax, imgWidth
    call WriteDec
    mov edx, OFFSET xMsg
    call WriteString
    mov eax, imgHeight
    call WriteDec
    call Crlf

    mov edx, OFFSET processingMsg
    call WriteString

    ; Dispatch selected operation.
    mov eax, menuChoice
    cmp eax, 1
    je DoInvert
    cmp eax, 2
    je DoGrayscale
    cmp eax, 3
    je DoThreshold
    cmp eax, 4
    je DoBrightness
    jmp DoMirror

DoInvert:
    call ApplyInvert
    jmp AskOutput
DoGrayscale:
    call ApplyGrayscale
    jmp AskOutput
DoThreshold:
    call ApplyThreshold
    jmp AskOutput
DoBrightness:
    call ApplyBrightness
    jmp AskOutput
DoMirror:
    call ApplyMirror

AskOutput:
    mov edx, OFFSET outputPrompt
    call WriteString
    mov edx, OFFSET outputName
    mov ecx, MAX_NAME_LENGTH
    call ReadString

    ; Prevent accidental overwrite when the same filename is entered.
    mov esi, OFFSET inputName
    mov edi, OFFSET outputName
NameCompare:
    mov al, BYTE PTR [esi]
    cmp al, BYTE PTR [edi]
    jne NamesAreDifferent
    test al, al
    jz SameNameEntered
    inc esi
    inc edi
    jmp NameCompare
SameNameEntered:
    mov edx, OFFSET sameNameMsg
    call WriteString
    jmp AskOutput
NamesAreDifferent:
    call WriteBMP
    cmp ioStatus, 1
    jne MainMenu

    mov edx, OFFSET savedMsg
    call WriteString
    mov edx, OFFSET outputName
    call WriteString
    call Crlf
    jmp MainMenu

InvalidChoice:
    mov edx, OFFSET invalidMenuMsg
    call WriteString
    jmp MainMenu

InvalidBMP:
    mov edx, OFFSET bmpErrorMsg
    call WriteString
    jmp MainMenu

ExitProgram:
    mov edx, OFFSET exitMsg
    call WriteString
    exit
main ENDP

; ------------------------------------------------------------
; ReadBMP: read the complete file into bmpBuffer.
; ioStatus = 1 on success, 0 on failure.
; ------------------------------------------------------------
ReadBMP PROC
    pushad
    mov ioStatus, 0
    mov bytesRead, 0

    mov edx, OFFSET inputName
    call OpenInputFile
    cmp eax, INVALID_HANDLE_VALUE
    je RB_OpenFailed
    mov inputHandle, eax

    mov eax, inputHandle
    mov edx, OFFSET bmpBuffer
    mov ecx, MAX_FILE_SIZE + 1
    call ReadFromFile
    jc RB_ReadFailed
    mov bytesRead, eax

    mov eax, inputHandle
    call CloseFile

    ; If the extra byte was filled, the file is larger than the limit.
    cmp bytesRead, MAX_FILE_SIZE
    ja RB_Failed

    mov ioStatus, 1
    jmp RB_Done

RB_ReadFailed:
    mov eax, inputHandle
    call CloseFile
    jmp RB_Failed
RB_OpenFailed:
    mov edx, OFFSET openErrorMsg
    call WriteString
    jmp RB_Done
RB_Failed:
    mov edx, OFFSET readErrorMsg
    call WriteString
RB_Done:
    popad
    ret
ReadBMP ENDP

; ------------------------------------------------------------
; ParseBMPHeader: validates a 24-bit BI_RGB BMP and calculates
; rowStride and padding. Supports positive/negative BMP height.
; ------------------------------------------------------------
ParseBMPHeader PROC
    pushad
    mov bmpValid, 0

    cmp bytesRead, 54
    jb PBH_Done
    cmp WORD PTR [bmpBuffer], 4D42h       ; "BM"
    jne PBH_Done

    mov eax, DWORD PTR [bmpBuffer + 14]   ; DIB header size
    cmp eax, 40
    jb PBH_Done
    mov dibHeaderSize, eax

    mov eax, DWORD PTR [bmpBuffer + 10]   ; pixel-data offset
    mov pixelOffset, eax
    cmp eax, 54
    jb PBH_Done
    cmp eax, bytesRead
    ja PBH_Done

    ; Pixel data must begin after the complete DIB header.
    mov eax, dibHeaderSize
    add eax, 14
    jc PBH_Done
    cmp pixelOffset, eax
    jb PBH_Done

    ; Width must be positive and no greater than 4096.
    mov eax, DWORD PTR [bmpBuffer + 18]
    test eax, eax
    jle PBH_Done
    cmp eax, 4096
    ja PBH_Done
    mov imgWidth, eax

    ; Height may be negative (top-down) or positive (bottom-up).
    mov eax, DWORD PTR [bmpBuffer + 22]
    test eax, eax
    jz PBH_Done
  cmp eax, 80000000h
je PBH_Done

test eax, eax
jns PBH_HeightReady

neg eax
PBH_HeightReady:
    cmp eax, 4096
    ja PBH_Done
    mov imgHeight, eax

    cmp WORD PTR [bmpBuffer + 26], 1      ; planes
    jne PBH_Done
    cmp WORD PTR [bmpBuffer + 28], 24    ; bits per pixel
    jne PBH_Done
    cmp DWORD PTR [bmpBuffer + 30], 0    ; BI_RGB, no compression
    jne PBH_Done

    ; rowStride = (width*3 + 3) rounded down to a multiple of 4.
    mov eax, imgWidth
    imul eax, 3
    add eax, 3
    and eax, 0FFFFFFFCh
    mov rowStride, eax

    mov ebx, imgWidth
    imul ebx, 3
    mov eax, rowStride
    sub eax, ebx
    mov rowPadding, eax

    ; Verify the complete pixel array fits within bytesRead.
    mov eax, rowStride
    mul imgHeight
    test edx, edx
    jnz PBH_Done
    mov pixelBytes, eax
    add eax, pixelOffset
    jc PBH_Done
    cmp eax, bytesRead
    ja PBH_Done

    mov bmpValid, 1
PBH_Done:
    popad
    ret
ParseBMPHeader ENDP

; ------------------------------------------------------------
; ApplyInvert: each B, G and R byte becomes 255 - old value.
; NOT on an 8-bit value performs exactly this transformation.
; ------------------------------------------------------------
ApplyInvert PROC
    pushad
    mov esi, OFFSET bmpBuffer
    add esi, pixelOffset
    mov ebx, rowPadding
    mov edi, imgHeight
AI_Row:
    mov ecx, imgWidth
AI_Pixel:
    not BYTE PTR [esi]
    not BYTE PTR [esi+1]
    not BYTE PTR [esi+2]
    add esi, 3
    loop AI_Pixel
    add esi, ebx
    dec edi
    jnz AI_Row
    popad
    ret
ApplyInvert ENDP

; ------------------------------------------------------------
; ApplyGrayscale: gray = (B + G + R) / 3; write gray to B,G,R.
; ------------------------------------------------------------
ApplyGrayscale PROC
    pushad
    mov esi, OFFSET bmpBuffer
    add esi, pixelOffset
    mov ebx, rowPadding
    mov edi, imgHeight
AG_Row:
    mov ecx, imgWidth
AG_Pixel:
    movzx eax, BYTE PTR [esi]
    movzx edx, BYTE PTR [esi+1]
    add eax, edx
    movzx edx, BYTE PTR [esi+2]
    add eax, edx
    xor edx, edx
    mov ebp, 3
    div ebp
    mov BYTE PTR [esi], al
    mov BYTE PTR [esi+1], al
    mov BYTE PTR [esi+2], al
    add esi, 3
    loop AG_Pixel
    add esi, ebx
    dec edi
    jnz AG_Row
    popad
    ret
ApplyGrayscale ENDP

; ------------------------------------------------------------
; ApplyThreshold: average < 128 => black; otherwise white.
; ------------------------------------------------------------
ApplyThreshold PROC
    pushad
    mov esi, OFFSET bmpBuffer
    add esi, pixelOffset
    mov ebx, rowPadding
    mov edi, imgHeight
AT_Row:
    mov ecx, imgWidth
AT_Pixel:
    movzx eax, BYTE PTR [esi]
    movzx edx, BYTE PTR [esi+1]
    add eax, edx
    movzx edx, BYTE PTR [esi+2]
    add eax, edx
    xor edx, edx
    mov ebp, 3
    div ebp
    cmp eax, 128
    jb AT_Black
    mov BYTE PTR [esi], 255
    mov BYTE PTR [esi+1], 255
    mov BYTE PTR [esi+2], 255
    jmp AT_Next
AT_Black:
    mov BYTE PTR [esi], 0
    mov BYTE PTR [esi+1], 0
    mov BYTE PTR [esi+2], 0
AT_Next:
    add esi, 3
    loop AT_Pixel
    add esi, ebx
    dec edi
    jnz AT_Row
    popad
    ret
ApplyThreshold ENDP

; ------------------------------------------------------------
; ApplyBrightness: add 30 to each channel, saturating at 255.
; ------------------------------------------------------------
ApplyBrightness PROC
    pushad
    mov esi, OFFSET bmpBuffer
    add esi, pixelOffset
    mov ebx, rowPadding
    mov edi, imgHeight
AB_Row:
    mov ecx, imgWidth
AB_Pixel:
    movzx eax, BYTE PTR [esi]
    add eax, 30
    cmp eax, 255
    jbe AB_B1
    mov eax, 255
AB_B1:
    mov BYTE PTR [esi], al

    movzx eax, BYTE PTR [esi+1]
    add eax, 30
    cmp eax, 255
    jbe AB_B2
    mov eax, 255
AB_B2:
    mov BYTE PTR [esi+1], al

    movzx eax, BYTE PTR [esi+2]
    add eax, 30
    cmp eax, 255
    jbe AB_B3
    mov eax, 255
AB_B3:
    mov BYTE PTR [esi+2], al

    add esi, 3
    loop AB_Pixel
    add esi, ebx
    dec edi
    jnz AB_Row
    popad
    ret
ApplyBrightness ENDP

; ------------------------------------------------------------
; ApplyMirror: reverse pixel order within each row (horizontal).
; Swap all three BGR bytes for symmetric pixels.
; ------------------------------------------------------------
ApplyMirror PROC
    pushad
    xor ebp, ebp                         ; row index
AM_Row:
    cmp ebp, imgHeight
    jae AM_Done

    mov eax, ebp
    imul eax, rowStride
    add eax, pixelOffset
    add eax, OFFSET bmpBuffer
    mov esi, eax                         ; left pixel

    mov eax, imgWidth
    dec eax
    imul eax, 3
    mov edi, esi
    add edi, eax                         ; right pixel

    mov ecx, imgWidth
    shr ecx, 1                           ; number of swaps
    jz AM_NextRow
AM_Swap:
    mov al, BYTE PTR [esi]
    mov dl, BYTE PTR [edi]
    mov BYTE PTR [esi], dl
    mov BYTE PTR [edi], al

    mov al, BYTE PTR [esi+1]
    mov dl, BYTE PTR [edi+1]
    mov BYTE PTR [esi+1], dl
    mov BYTE PTR [edi+1], al

    mov al, BYTE PTR [esi+2]
    mov dl, BYTE PTR [edi+2]
    mov BYTE PTR [esi+2], dl
    mov BYTE PTR [edi+2], al

    add esi, 3
    sub edi, 3
    loop AM_Swap
AM_NextRow:
    inc ebp
    jmp AM_Row
AM_Done:
    popad
    ret
ApplyMirror ENDP

; ------------------------------------------------------------
; WriteBMP: write bytesRead bytes from bmpBuffer to outputName.
; ioStatus = 1 on success, 0 on failure.
; ------------------------------------------------------------
WriteBMP PROC
    pushad
    mov ioStatus, 0
    mov edx, OFFSET outputName
    call CreateOutputFile
    cmp eax, INVALID_HANDLE_VALUE
    je WB_CreateFailed
    mov outputHandle, eax

    mov eax, outputHandle
    mov edx, OFFSET bmpBuffer
    mov ecx, bytesRead
    call WriteToFile
    jc WB_WriteFailed
    mov bytesWritten, eax

    mov eax, outputHandle
    call CloseFile

    mov eax, bytesWritten
    cmp eax, bytesRead
    jne WB_WriteError
    mov ioStatus, 1
    jmp WB_Done

WB_WriteFailed:
    mov eax, outputHandle
    call CloseFile
WB_WriteError:
    mov edx, OFFSET writeErrorMsg
    call WriteString
    jmp WB_Done
WB_CreateFailed:
    mov edx, OFFSET createErrorMsg
    call WriteString
WB_Done:
    popad
    ret
WriteBMP ENDP

END main
